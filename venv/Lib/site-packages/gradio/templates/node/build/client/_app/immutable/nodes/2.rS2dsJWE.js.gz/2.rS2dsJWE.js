import { z, _ } from "../chunks/2.PPgBkxOB.js";
export {
  z as component,
  _ as universal
};
